#!/usr/bin/env python2.7
'''� 2019 The Johns Hopkins University Applied Physics Laboratory LLC.� All Rights Reserved.
Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE'''



from __future__ import print_function

import sys, os, time, random
import argparse 
from collections import OrderedDict, Counter
from math import log10 
import matplotlib.pyplot as plt
import numpy as np
import operator
import pandas as pd
import signal
from matplotlib.pyplot import figure

# non-standard imports
# graph_tool is at https://graph-tool.skewed.de/
import graph_tool, graph_tool.generation, graph_tool.draw

pd.set_option('display.max_rows', 200)

def signal_handler(signal, frame):
    print('# signal_handler(): Cleaning up after ctrl-c.\n')
    sys.exit(0)

def target_powerlaw(x, m, c, c0):
    return c0 + x**m * c


def string2list(row):
    # convert string of list of ints read in from csv file
    row = row.strip('[').strip(']')
    # string might be list with one element, eg, "[1]"
    if row.count(',') > 0:
        row = row.split(', ')
    else:
        if len(row) > 0:
            row = [int(row)]
    if len(row) > 0:
        return [int(i) for i in row]
    else:
        return []

def recursive_len(item):
    if type(item) == list:
        return sum(recursive_len(subitem) for subitem in item)
    else:
        return 1

def create_graph(graph_type='price', num_nodes=100):
    # example of new property    
    #name = full_dgraph.new_vertex_property('string')
    #full_dgraph.vertex_properties['name'] = name
    if graph_type == 'price':
        graph = graph_tool.generation.price_network(num_nodes, m=1, c=1, gamma=0.5, directed=True)
        # randomly reverse direction of some edges
        for edge in graph.edges():
            if random.random() > 0.5:
                new_src = int(edge.target())
                new_tgt = int(edge.source())
                graph.remove_edge(edge)
                graph.add_edge(new_src, new_tgt, add_missing=False)
    return graph


def num_plot(x, y, title=None, xlabel=None, ylabel=None, colors=None, legend_labels=None, num_xy=None, markers=None, plot_type='standard', save_fig=False):
    if plot_type not in ['standard', 'log-log', 'semi-log']:
        print('# plot_type must be one of  [\'standard\', \'log-log\', \'semi-log\']. cannot create plot')
        return

    if not all(isinstance(elem, list) for elem in x) or not all(isinstance(elem, list) for elem in y):
        print('# x and y must be lists of data')
        return 
    
    fig, ax = plt.subplots(figsize=(25,12))
    plt.subplots_adjust(bottom=0.1, top=0.9, right=0.9, left=0.1)
    width = 0.4
    if colors is None:
        colors = ['m','c','r','b']
    if markers is None:
        markers = ['o','d','o','d']
    markersize = 5
    max_x = 0
    max_y = 0
    # x and y are lists of lists - num_xy is the number of lists each in x and y
    # lets us plot over multiple data sets like Curve and In-Neighs
    if num_xy is None:
        print('# Error in [x], [y]')
        return
    if legend_labels is None:
        for count in range(0,num_xy):
            if isinstance(x[count], list) and isinstance(y[count], list):
                for i in range(len(x[count])):
                    ax.plot(x[count][i], y[count][i], c=colors[count], marker=markers[count], markersize=markersize, linestyle='None')
            else:
                ax.plot(x[count], y[count], c=colors[count], marker=markers[count], markersize=markersize, linestyle='None')
    else:
        for count in range(0,num_xy):
            if isinstance(x[count], list) and isinstance(y[count], list):
                for i in range(len(x[count])):
                    ax.plot(x[count][i], y[count][i], c=colors[count], label=legend_labels[count], marker=markers[count], markersize=markersize, linestyle='None')
            else:
                ax.plot(x[count], y[count], c=colors[count], label=legend_labels[count], marker=markers[count], markersize=markersize, linestyle='None')
    
    if plot_type == 'standard':
        ax.set_xlim((0,3501))
        ax.set_ylim((0,141))
        #ax.set_xticks(np.arange(0,max_x+1, int((max_x+1)/20)))
        #ax.set_yticks(np.arange(0,max_y+1, int((max_y+1)/10)))
        ax.set_xticks(np.arange(0,3501,500))
        ax.set_yticks(np.arange(0,141,10))
    elif plot_type=='semi-log':
        plt.yscale('log')
        ax.set_xlim((0,3501))
        ax.set_ylim((0.01,2.1))
        ax.set_xticks(np.arange(0,3501,500))
        ax.set_yticks(np.arange(.01,2.1,0.5))
    elif plot_type=='log-log':
        plt.xscale('log')
        plt.yscale('log')
        ax.set_xlim((0.01,3.8))
        ax.set_ylim((0.01,2.1))
        ax.set_xticks(np.arange(0.01,3.8,0.1))
        ax.set_yticks(np.arange(0.1,2.1,0.1))
    
    for tick in ax.xaxis.get_major_ticks():
        tick.label.set_fontsize(18) 
    for tick in ax.xaxis.get_minor_ticks():
        tick.label.set_fontsize(18) 
    for tick in ax.yaxis.get_major_ticks():
        tick.label.set_fontsize(18) 
    for tick in ax.yaxis.get_minor_ticks():
        tick.label.set_fontsize(18) 
    plt.title(title, fontsize=24, loc='left')
    plt.xlabel(xlabel, fontsize=24)
    plt.ylabel(ylabel, fontsize=24)
    if legend_labels is not None:
        # only get unique entries in legend
        handles, labels = ax.get_legend_handles_labels()
        unique_labels = np.unique(labels, return_index=True)
        labels = unique_labels[0]
        handle = []
        for i in unique_labels[1]:
            handle.append(handles[i])
        handles = handle
        ax.legend(handles, labels, bbox_to_anchor=(0.995, 1.05), ncol=3)
    if save_fig is not False:  # it's the name of the file
        plt.savefig(save_fig+'.png', bbox_inches='tight')
    plt.show()
    return


# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# __main__
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

signal.signal(signal.SIGINT, signal_handler)
new_graph_types = ['price']

parser = argparse.ArgumentParser()
# must specify reading an existing graph from a GraphML file or generating a new graph
group = parser.add_mutually_exclusive_group(required=True)
parser.add_argument('--graph-name', required=True, action='store', dest='graph_name', help='Name of the graph to appear in plots.')
group.add_argument('--graphml', required=False, type=str, default=None, action='store', help='Name of GraphML formatted file to read.')
group.add_argument('--new', required=False, type=str, default=None, action='store', help='Generate a new graph of type. Requires --nodes and --edges arguments.')
parser.add_argument('--nodes', required=False, type=int, default=None, action='store', help='Number of nodes in generated graph.')
parser.add_argument('--save', required=False, type=str, default=None, action='store', help='Fillename to save graph (GraphML format).')
parser.add_argument('--show-graph', required=False, action='store_true', dest='show_graph', help='Show the network graph. Will be veeeerrrry slow for large graphs. Default is to NOT show the graph.')
parser.add_argument('--show-neighbors-offset', required=False, action='store_true', dest='show_neighbors_offset', help='Show the neighbor node degree values offset on the Y-axis. Used to show neighbor nodes that are hidden due to multiple same values.')

args = parser.parse_args()
graph_name = args.graph_name
if args.new and args.new not in new_graph_types:
    parser.error('Can only generate a new graph from types: %s'%new_graph_types)
if args.new and args.nodes is None and args.edges is None:
    parser.error('# Generating a new graph requires specifying --nodes argument.')

# load the graph
if args.new == 'price':
    graph = create_graph(graph_type='price', num_nodes=args.nodes)
elif args.graphml:
    print('# Loading graph from GraphML file',args.graphml)
    graph = graph_tool.load_graph(args.graphml)
else:  # should never reach this state, but just in case...
    print('# Must specify a GraphML file to read or create a new graph.')

if graph.is_directed():
    print('# input graph is directed')
else:
    print('# input graph is undirected')
    
# show graph, if requested
if args.show_graph:
    pos = graph_tool.draw.sfdp_layout(graph)
    graph_tool.draw.graph_draw(graph, pos)

# write out to GraphML file
if args.save:
    print('# Saving graph to GraphML file',args.save)
    graph.save(args.save, 'graphml')


if os.path.isfile(graph_name.strip('.graphml')+'.csv'):
    print('# reading file'+graph_name.strip('.graphml')+'.csv')
    nodes = pd.read_csv(graph_name.strip('.graphml')+'.csv')
    list_cols = ['out neighs','out neighs degree','out neighs rank',
                 'in neighs','in neighs degree','in neighs rank',
                 'total neighs','total neighs degree','total neighs rank']
    for col in list_cols:
        nodes[col] = nodes[col].apply(string2list)
        
else:
    print('# calculating from graph file', graph_name)
    num_nodes = len(graph.get_vertices())
    # only using the first row of values for now
    feature_list = ['node number','total degree','total rank',
                    'out deg', 'out neighs', 'out neighs degree', 'out neighs rank', 
                    'in deg', 'in neighs', 'in neighs degree', 'in neighs rank', 
                    'total neighs', 'total neighs degree', 'total neighs rank'
                   ]
    zero_data = np.zeros(shape=(num_nodes,len(feature_list)))
    pd.options.mode.chained_assignment = None
    nodes = pd.DataFrame(zero_data, columns=feature_list, dtype=np.int32)
    # allows the element to be lists as pd.Series --> pd.Series([[1,2,3]])
    nodes['in neighs'] = pd.Series([[]]*num_nodes)
    nodes['out neighs'] = pd.Series([[]]*num_nodes)    
    nodes['total neighs'] = pd.Series([[]]*num_nodes)    
    nodes['in neighs degree'] = pd.Series([[]]*num_nodes)
    nodes['out neighs degree'] = pd.Series([[]]*num_nodes)    
    nodes['total neighs degree'] = pd.Series([[]]*num_nodes)    
    nodes['in neighs rank'] = pd.Series([[]]*num_nodes)
    nodes['out neighs rank'] = pd.Series([[]]*num_nodes)    
    nodes['total neighs rank'] = pd.Series([[]]*num_nodes)    
    
    ## 1) Calculate the degree of each node (which requires M calculations)
    # load graph into dataframe
    node_num = []
    in_degree = []
    out_degree = []
    in_neighs = []
    out_neighs = []
    in_neighs_degree = []
    out_neighs_degree = []

    for i,node in enumerate(graph.vertices()):
        node_num.append(int(node))
        out_degree.append(node.out_degree())
        in_degree.append(node.in_degree())
        tmp = []
        for neigh in graph.get_out_neighbours(int(node)):
            tmp.append(int(neigh))
        out_neighs.append(tmp) 
        tmp = []
        for neigh in graph.get_in_neighbours(int(node)):
            tmp.append(int(neigh))
        in_neighs.append(tmp)        
        tmp = []
        for neigh in out_neighs[-1]:
            out_deg = int(graph.vertex(neigh).out_degree())
            in_deg = int(graph.vertex(neigh).in_degree())
            tmp.append(in_deg+out_deg)
        out_neighs_degree.append(tmp)
        tmp = []
        for neigh in in_neighs[-1]:
            in_deg = int(graph.vertex(neigh).in_degree())
            out_deg = int(graph.vertex(neigh).out_degree())
            tmp.append(in_deg+out_deg)
        in_neighs_degree.append(tmp)
        
    nodes['node number'] = node_num
    nodes['out deg'] = out_degree
    nodes['out neighs'] = out_neighs
    nodes['out neighs degree'] = out_neighs_degree
    if graph.is_directed():
        nodes['in deg'] = in_degree
        nodes['in neighs'] = in_neighs
        nodes['in neighs degree'] = in_neighs_degree    
    nodes['total degree'] = nodes['out deg'] + nodes['in deg'] 
    nodes['total neighs'] = nodes['out neighs'] + nodes['in neighs']
    nodes['total neighs degree'] = nodes['out neighs degree'] + nodes['in neighs degree']
    
    # 2) Sort the nodes by degree, assigning the highest degree node a rank of 1
    #         and similarly rank all subsequent nodes to Rank N.
    print('# sorting node list by degree value')
    nodes.sort_values('total degree', ascending=False, inplace=True)
    nodes.reset_index(inplace=True)
    nodes['total rank'] = nodes.index+1
    
    print('# finding in/out neigh rank')
    # make lists of ranks of neighbors
    in_rank = []
    out_rank = []
    for n in range(len(nodes)):
        rank = []
        # get the neighbors of each node
        for neigh in nodes.iloc[n]['in neighs']:
            rank.append(nodes['node number'][nodes['node number'] == neigh].index[0]+1)
        in_rank.append(rank)
        rank = []
        for neigh in nodes.iloc[n]['out neighs']:
            rank.append(nodes['node number'][nodes['node number'] == neigh].index[0]+1)
        out_rank.append(rank)    
    nodes['in neighs rank'] = in_rank
    nodes['out neighs rank'] = out_rank
    nodes['total neighs rank'] = nodes['in neighs rank'] + nodes['out neighs rank']    
    if 'index' in nodes.columns:
        nodes.drop('index', axis=1, inplace=True)
    nodes.sort_values('total rank').to_csv(graph_name.strip('.graphml')+'.csv', index=False)
    
start_time = time.time()
print('starting harball buster calculations')
# for nodes curve - each nodes total degree vs. its rank 
nodes_rank = list(nodes['total rank'])
nodes_degree = list(nodes['total degree'])

# 4) for each node - get the degrees of all neighbors sum them
out_rank = {'x':[], 'y':[]}
in_rank = {'x':[], 'y':[]}
inout_rank = {'x':[], 'y':[]}

len_out_neighs = nodes['out neighs rank'].str.len().values.tolist()
out_rank['x'] = nodes['out neighs rank'].values.tolist()
out_rank['y'] = [[node]*len_out_neighs[i] for i,node in enumerate(nodes['total degree'].values.tolist())]
for i in range(len(out_rank['x'])):
    out_rank['x'][i] = sorted(out_rank['x'][i])

len_in_neighs = nodes['in neighs rank'].str.len().values.tolist()
in_rank['x'] = nodes['in neighs rank'].values.tolist()
in_rank['y'] = [[node]*len_in_neighs[i] for i,node in enumerate(nodes['total degree'].values.tolist())]
for i in range(len(in_rank['x'])):
    in_rank['x'][i] = sorted(in_rank['x'][i])

# combine in_rank and out_rank lists
#  for graph-tool:  "For undirected graphs, the 'out-degree' is synonym for degree ..."
if not graph.is_directed():   
    inout_rank['x'] = [a for a in out_rank['x']]
    inout_rank['y'] = [sorted(a) for a in out_rank['y']]
else:
    inout_rank['x'] = [a+b for a,b in zip(out_rank['x'],in_rank['x'])]
    inout_rank['y'] = [sorted(a+b) for a,b in zip(out_rank['y'],in_rank['y'])]
    
    
if args.show_neighbors_offset:
    # note - this makes sense only for neighbor plots
    # two types of duplications to offset.
    #   1. value in ['y'] list also appears in ['x'] list (overlap with neighbor curve overlaps with total rank curve)
    #   2. duplicate values in ['y'] list
    # put in code to offset same valued neighbor node Y-values
    # look for values in ['x'] that are also in ['y'] list
    print('# showing duplicate neighbor values as offset')
    x_vals = nodes_rank
    all_node_points = [[xpt,ypt] for xpt,ypt in zip(nodes_rank,nodes_degree)]
    all_node_points = sorted(all_node_points, key=lambda point: (point[0], point[1]))
    
    all_neigh_points = [[xpt,ypt] for xlist,ylist in zip(inout_rank['x'],inout_rank['y'])
                            for xpt, ypt in zip(xlist, ylist)]
    all_neigh_points = sorted(all_neigh_points, key=lambda point: (point[0], point[1]))
    new_neigh_pts = []
    offset_val = 0.2
    for x in x_vals:
        lst = [el for el in all_neigh_points if el[0]==x]
        # 1. check if any of all_neigh_points are in all_node_points
        for i,el in enumerate(lst):
            count = 1
            if el in all_node_points:
                lst[i][1] += round(offset_val*(count%(1/offset_val)), 2)
                count += 1
        # 2. check if any duplicates in the list of neigh points 
        lst_counter = Counter(map(tuple,lst))
        last_el = [-1, -1]
        new_lst = []
        count = 0
        for i,el in enumerate(lst):
            if el != last_el:
                count = 0
            if lst_counter[tuple(el)] > 1:
                new_y = el[1]+offset_val*(count%(1/offset_val))
                new_lst.append([el[0], round(new_y, 2)])
                count += 1
            else:
                new_lst.append(el)    
            last_el = el
        new_neigh_pts += new_lst    
        
    x = [a[0] for a in new_neigh_pts] + \
        [a for a in nodes_rank]
    y = [a[1] for a in new_neigh_pts] + \
        [a for a in nodes_degree]
    colors = ['gray'] * len([b for a in inout_rank['x'] for b in a]) + \
             ['blue'] * len(nodes_rank)   
    pt_size = [2] * len([b for a in inout_rank['x'] for b in a]) + \
              [8] * len(nodes_rank)    
           
else:
    # standard plots
    x = [b for a in inout_rank['x'] for b in a] + \
        [a for a in nodes_rank]
    # for "Total Rank / Degree Curve" plot - uncomment this line. For "Neighbor Nodes" plot - comment out this line
    #x = [a for a in nodes_rank]
    #x = [np.log(a+1) for a in nodes_rank]
    
    y = [b for a in inout_rank['y'] for b in a] + \
        [a for a in nodes_degree]
    # for "Total Rank / Degree Curve" plot - uncomment this line. For "Neighbor Nodes" plot - comment out this line
    #y = [a for a in nodes_degree]
    #y = [np.log(b+1) for a in in_rank['y'] for b in a] + \
    #    [np.log(b+1) for a in out_rank['y'] for b in a] + \
    #    [np.log(a+1) for a in nodes_degree]
    #y = [np.log(a+1) for a in nodes_degree]
    
    colors = ['gray'] * len([b for a in inout_rank['x'] for b in a]) + \
             ['blue'] * len(nodes_rank)   
    # for "Total Rank / Degree Curve" plot - uncomment this line. For "Neighbor Nodes" plot - comment out this line
    #colors = ['blue'] * len(nodes_rank)   
    
    pt_size = [2] * len([b for a in inout_rank['x'] for b in a]) + \
              [8] * len(nodes_rank)
    # for "Total Rank / Degree Curve" plot - uncomment this line. For "Neighbor Nodes" plot - comment out this line
    #pt_size = [8] * len(nodes_rank)


print('# plotting...')
df_plot = pd.DataFrame(columns=['x','y'])   
df_plot['x'] = x
df_plot['y'] = y
df_plot['colors'] = colors
df_plot['point size'] = pt_size

xlim = [-1,250]
#xlim = [0,10.2]
ylim=[-1,250]
xticks = np.arange(0, 255, 25)
#xticks = np.arange(0, 10.1, 1)
yticks = np.arange(0, 255, 25)
#yticks = np.arange(4.5, 7.5, 0.5)

ax = df_plot.plot.scatter(x='x', y='y', s=df_plot['point size'], color=df_plot['colors'], 
                     figsize=(19,9.5), fontsize=16, 
                     xlim=xlim, ylim=ylim, 
                     xticks=xticks, yticks=yticks,
                     #logy=True
                     )

plt.title('Neighbor Nodes ['+graph_name+']', fontsize=18)
# for "Total Rank / Degree Curve" plot - uncomment this line. For "Neighbor Nodes" plot - comment out this line
#plt.title('Total Rank / Degree Curve ['+graph_name+']', fontsize=18)

plt.xlabel('Node Rank', fontsize=16)
plt.ylabel('Node Degree', fontsize=16)

print('elapsed time %.2f'%(time.time()-start_time))

#plt.show()



sys.exit(0)
