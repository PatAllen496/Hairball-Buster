#!/usr/bin/env python
'''� 2019 The Johns Hopkins University Applied Physics Laboratory LLC.� All Rights Reserved.
Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE'''


from __future__ import print_function

import sys, os, time, random
import argparse 
from collections import OrderedDict
from math import log10 
import matplotlib.pyplot as plt
import numpy as np
import operator
import pandas as pd
import signal

from matplotlib.pyplot import figure

# non-standard imports
# graph_tool is at https://graph-tool.skewed.de/
import graph_tool, graph_tool.generation, graph_tool.draw


pd.set_option('display.max_rows', 200)

def signal_handler(signal, frame):
    print('# signal_handler(): Cleaning up after ctrl-c.\n')
    sys.exit(0)

def target_powerlaw(x, m, c, c0):
    return c0 + x**m * c


def string2list(row):
    # convert string of list of ints read in from csv file
    row = row.strip('[').strip(']').split(', ')
    if len(row) > 1:
        return [int(i) for i in row]
    else:
        return []

def recursive_len(item):
    if type(item) == list:
        return sum(recursive_len(subitem) for subitem in item)
    else:
        return 1

def create_graph(graph_type='price', num_nodes=100):
    # example of new property    
    #name = full_dgraph.new_vertex_property('string')
    #full_dgraph.vertex_properties['name'] = name
    if graph_type == 'price':
        graph = graph_tool.generation.price_network(num_nodes, m=1, c=1, gamma=0.5, directed=True)
        # randomly reverse direction of some edges
        for edge in graph.edges():
            if random.random() > 0.5:
                new_src = int(edge.target())
                new_tgt = int(edge.source())
                graph.remove_edge(edge)
                graph.add_edge(new_src, new_tgt, add_missing=False)
    return graph


def num_plot(x, y, title=None, xlabel=None, ylabel=None, colors=None, legend_labels=None, num_xy=None, markers=None, plot_type='standard', save_fig=False):
    if plot_type not in ['standard', 'log-log', 'semi-log']:
        print('plot_type must be one of  [\'standard\', \'log-log\', \'semi-log\']. cannot create plot')
        return

    if not all(isinstance(elem, list) for elem in x) or not all(isinstance(elem, list) for elem in y):
        print('x and y must be lists of data')
        return 
    
    fig, ax = plt.subplots(figsize=(25,12))
    plt.subplots_adjust(bottom=0.1, top=0.9, right=0.9, left=0.1)
    width = 0.4
    if colors is None:
        colors = ['m','c','r','b']
    if markers is None:
        markers = ['o','d','o','d']
    markersize = 5
    max_x = 0
    max_y = 0
    # x and y are lists of lists - num_xy is the number of lists each in x and y
    # lets us plot over multiple data sets like Curve and In-Neighs
    if num_xy is None:
        print('Error in [x], [y]')
        return
    if legend_labels is None:
        for count in range(0,num_xy):
            if isinstance(x[count], list) and isinstance(y[count], list):
                for i in range(len(x[count])):
                    ax.plot(x[count][i], y[count][i], c=colors[count], marker=markers[count], markersize=markersize, linestyle='None')
            else:
                ax.plot(x[count], y[count], c=colors[count], marker=markers[count], markersize=markersize, linestyle='None')
    else:
        for count in range(0,num_xy):
            if isinstance(x[count], list) and isinstance(y[count], list):
                for i in range(len(x[count])):
                    ax.plot(x[count][i], y[count][i], c=colors[count], label=legend_labels[count], marker=markers[count], markersize=markersize, linestyle='None')
            else:
                ax.plot(x[count], y[count], c=colors[count], label=legend_labels[count], marker=markers[count], markersize=markersize, linestyle='None')
    
    if plot_type == 'standard':
        ax.set_xlim((0,3501))
        ax.set_ylim((0,141))
        #ax.set_xticks(np.arange(0,max_x+1, int((max_x+1)/20)))
        #ax.set_yticks(np.arange(0,max_y+1, int((max_y+1)/10)))
        ax.set_xticks(np.arange(0,3501,500))
        ax.set_yticks(np.arange(0,141,10))
    elif plot_type=='semi-log':
        plt.yscale('log')
        ax.set_xlim((0,3501))
        ax.set_ylim((0.01,2.1))
        ax.set_xticks(np.arange(0,3501,500))
        ax.set_yticks(np.arange(.01,2.1,0.5))
    elif plot_type=='log-log':
        plt.xscale('log')
        plt.yscale('log')
        ax.set_xlim((0.01,3.8))
        ax.set_ylim((0.01,2.1))
        ax.set_xticks(np.arange(0.01,3.8,0.1))
        ax.set_yticks(np.arange(0.1,2.1,0.1))
    
    for tick in ax.xaxis.get_major_ticks():
        tick.label.set_fontsize(18) 
    for tick in ax.xaxis.get_minor_ticks():
        tick.label.set_fontsize(18) 
    for tick in ax.yaxis.get_major_ticks():
        tick.label.set_fontsize(18) 
    for tick in ax.yaxis.get_minor_ticks():
        tick.label.set_fontsize(18) 
    plt.title(title, fontsize=24, loc='left')
    plt.xlabel(xlabel, fontsize=24)
    plt.ylabel(ylabel, fontsize=24)
    if legend_labels is not None:
        # only get unique entries in legend
        handles, labels = ax.get_legend_handles_labels()
        unique_labels = np.unique(labels, return_index=True)
        labels = unique_labels[0]
        handle = []
        for i in unique_labels[1]:
            handle.append(handles[i])
        handles = handle
        ax.legend(handles, labels, bbox_to_anchor=(0.995, 1.05), ncol=3)
    if save_fig is not False:  # it's the name of the file
        plt.savefig(save_fig+'.png', bbox_inches='tight')
    plt.show()
    return


# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# __main__
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

signal.signal(signal.SIGINT, signal_handler)
new_graph_types = ['price']

parser = argparse.ArgumentParser()
# must specify reading an existing graph from a GraphML file or generating a new graph
group = parser.add_mutually_exclusive_group(required=True)
parser.add_argument('--graph-name', required=True, action='store', dest='graph_name', help='Name of the graph to appear in plots.')
group.add_argument('--graphml', required=False, type=str, default=None, action='store', help='Name of GraphML formatted file to read.')
group.add_argument('--new', required=False, type=str, default=None, action='store', help='Generate a new graph of type. Requires --nodes and --edges arguments.')
parser.add_argument('--nodes', required=False, type=int, default=None, action='store', help='Number of nodes in generated graph.')
parser.add_argument('--save', required=False, type=str, default=None, action='store', help='Fillename to save graph (GraphML format).')
parser.add_argument('--show-graph', required=False, action='store_true', dest='show_graph', help='Show the network graph. Will be veeeerrrry slow for large graphs. Default is to NOT show the graph.')
which_group = parser.add_mutually_exclusive_group(required=False)
which_group.add_argument('--first-3500', required=False, action='store_true', help='Use only the first 3500 nodes in the graph (0-3499).')
which_group.add_argument('--next-3500', required=False, action='store_true', help='Use only the next 3500 nodes in the graph (3500-6999).')
which_group.add_argument('--next-next-3500', required=False, action='store_true', help='Use only the next next 3500 nodes in the graph (7000-10499).')

args = parser.parse_args()
graph_name = args.graph_name
if args.new and args.new not in new_graph_types:
    parser.error('Can only generate a new graph from types: %s'%new_graph_types)
if args.new and args.nodes is None and args.edges is None:
    parser.error('# Generating a new graph requires specifying --nodes argument.')

# load the graph
if args.new == 'price':
    graph = create_graph(graph_type='price', num_nodes=args.nodes)
elif args.graphml:
    print('# Loading graph from GraphML file',args.graphml)
    graph = graph_tool.load_graph(args.graphml)
else:  # should never reach this state, but just in case...
    print('# Must specify a GraphML file to read or create a new graph.')

if graph.is_directed():
    print('# input graph is directed')
else:
    print('# input graph is undirected')
    
# show graph, if requested
if args.show_graph:
    pos = graph_tool.draw.sfdp_layout(graph)
    graph_tool.draw.graph_draw(graph, pos)

# write out to GraphML file
if args.save:
    print('# Saving graph to GraphML file',args.save)
    graph.save(args.save, 'graphml')

if args.first_3500:
    start_node = 0
    stop_node = 3500
    plot_title = 'First 3500 '
    csv_name = ' first-3500'
elif args.next_3500:
    start_node = 3500
    stop_node = 7000
    plot_title = 'Next 3500 '
    csv_name = 'next-3500'
elif args.next_next_3500:
    start_node = 7000
    stop_node = 10500
    plot_title = 'Next Next 3500 '
    csv_name = 'next-next-3500'
else:
    start_node = 0
    stop_node = len(graph.get_vertices())
    plot_title = ''
    csv_name = ''
    
if os.path.isfile(graph_name.strip('.graphml')+'first-3500.csv'):
    print('reading file'+graph_name.strip('.graphml')+'.csv')
    nodes = pd.read_csv(graph_name.strip('.graphml')+'.csv')
    cols = ['in neighs','in neighs rank','out neighs','out neighs rank','total neighs','total neighs rank']
    for col in cols:
        nodes[col] = nodes[col].apply(string2list)

else:
    print('calculating from graph file', graph_name)
    # filter out all except first 3500 nodes
    vfilter = graph.new_vertex_property('bool', val=False)
    for i,node in enumerate(graph.vertices()):
        if i >= start_node and i < stop_node:
            vfilter[node] = True
            if i > stop_node:
                break
    # to reset graph
    #graph.set_vertex_filter(None)
    graph.set_vertex_filter(vfilter)
    num_nodes = len(graph.get_vertices())
    print('graph has', num_nodes,'nodes. using nodes ',start_node,'through',stop_node-1)
    feature_list = ['node number', 'node name', 'total degree','total rank','in deg', 'out deg', 
                    'in neighs', 'in neighs rank', 'out neighs', 'out neighs rank', 
                    'total neighs', 'total neighs rank'
                   ]
    zero_data = np.zeros(shape=(num_nodes,len(feature_list)))
    pd.options.mode.chained_assignment = None
    nodes = pd.DataFrame(zero_data, columns=feature_list, dtype=np.int32)
    # allows the element to be lists as pd.Series --> pd.Series([[1,2,3]])
    nodes['node name'] = pd.Series([[]]*num_nodes)
    nodes['in neighs'] = pd.Series([[]]*num_nodes)
    nodes['out neighs'] = pd.Series([[]]*num_nodes)    
    nodes['total neighs'] = pd.Series([[]]*num_nodes)    
    nodes['in neighs rank'] = pd.Series([[]]*num_nodes)
    nodes['out neighs rank'] = pd.Series([[]]*num_nodes)    
    nodes['total neighs rank'] = pd.Series([[]]*num_nodes)    
        
    ## 1) Calculate the degree of each node (which requires M calculations)
    # load graph into dataframe
    node_num = []
    in_degree = []
    out_degree = []
    in_neighs = []
    out_neighs = []
    node_name = []
    
    for i,node in enumerate(graph.vertices()):
        node_num.append(int(node))
        in_degree.append(node.in_degree())
        out_degree.append(node.out_degree())
        tmp = []
        for neigh in graph.get_in_neighbours(int(node)):
            tmp.append(int(neigh))
        in_neighs.append(tmp)
        tmp = []
        for neigh in graph.get_out_neighbours(int(node)):
            tmp.append(int(neigh))
        out_neighs.append(tmp)
        node_name.append(graph.vp._graphml_vertex_id[node])

    nodes['node number'] = node_num
    nodes['node name'] = node_name
    nodes['in deg'] = in_degree
    nodes['out deg'] = out_degree
    nodes['in neighs'] = in_neighs
    nodes['out neighs'] = out_neighs
    nodes['total degree'] = nodes['in deg'] + nodes['out deg'] 
    nodes['total neighs'] = nodes['in neighs'] + nodes['out neighs']
    
    # 2) Sort the nodes by degree, assigning the highest degree node a rank of 1
    #         and similarly rank all subsequent nodes to Rank N.
    print('# sorting node list by degree value')
    nodes.sort_values('total degree', ascending=False, inplace=True)
    nodes.reset_index(inplace=True)
    nodes['total rank'] = nodes.index+1
    
    print('# finding in/out neigh rank')
    # make lists of ranks of neighbors
    in_rank = []
    out_rank = []
    for n in range(len(nodes)):
        rank = []
        # get the neighbors of each node
        for neigh in nodes.iloc[n]['in neighs']:
            rank.append(nodes['node number'][nodes['node number'] == neigh].index[0]+1)
        in_rank.append(rank)
        rank = []
        for neigh in nodes.iloc[n]['out neighs']:
            rank.append(nodes['node number'][nodes['node number'] == neigh].index[0]+1)
        out_rank.append(rank)    
    nodes['in neighs rank'] = in_rank
    nodes['out neighs rank'] = out_rank
    nodes['total neighs rank'] = nodes['in neighs rank'] + nodes['out neighs rank']    
    if 'index' in nodes.columns:
        nodes.drop('index', axis=1, inplace=True)
    nodes.sort_values('total rank').to_csv(graph_name.strip('.graphml')+csv_name+'.csv', index=False)
    
    
nodes_rank = list(nodes['total rank'])
nodes_degree = list(nodes['total degree'])

#    whose X coordinate is the total (in+out) rank of each node and the Y coordinate is the total (in+out) degree of each node.  
# A. plot the "curve" = total_degree vs total_rank (y vs x)
print('# plotting...')
#num_plot(x=[nodes_rank], y=[nodes_degree], title='Curve Nodes ['+graph_name+']', 
#         xlabel='Total Node Rank', ylabel='Total Node Degree',
#         colors=['b'], markers=['o'], num_xy=1, save_fig='Curve-01')


# 4) for each node - get the degrees of all neighbors sum them
in_rank = {'x':[], 'y':[]}
out_rank = {'x':[], 'y':[]}
len_in_neighs = nodes['in neighs rank'].str.len().values.tolist()
in_rank['x'] = nodes['in neighs rank'].values.tolist()
in_rank['y'] = [[node]*len_in_neighs[i] for i,node in enumerate(nodes['total degree'].values.tolist())]
len_out_neighs = nodes['out neighs rank'].str.len().values.tolist()
out_rank['x'] = nodes['out neighs rank'].values.tolist()
out_rank['y'] = [[node]*len_out_neighs[i] for i,node in enumerate(nodes['total degree'].values.tolist())]


# write data out to Excel file - separate sheets for curve, in_neighs and out_neighs
if not os.path.isfile(graph_name.strip('.graphml')+'.xlsx'):
    writer = pd.ExcelWriter(graph_name.strip('.graphml')+'.xlsx', engine='xlsxwriter')
    df = pd.DataFrame(columns=['total rank','log(total degree+1)'])
    df['total rank'] = nodes['total rank']
    df['total degree'] = nodes['total degree']
    df['log(total rank+1)'] = [np.log(b+1) for b in nodes['total rank'].values.tolist()]
    df['log(total degree+1)'] = [np.log(b+1) for b in nodes['total degree'].values.tolist()]
    cols = ['total rank','total degree','total rank','log(total degree+1)','log(total rank+1)','log(total degree+1)']
    df[cols].to_excel(writer, sheet_name='curve - rank|degree', index=False)
    df = pd.DataFrame(columns=['in_rank[x]','in_rank[y]'])
    df['in_rank[x]'] = [b for a in in_rank['x'] for b in a]
    df['in_rank[y]'] = [b for a in in_rank['y'] for b in a]
    df['log(in_rank[x]+1)'] = [np.log(b+1) for a in in_rank['x'] for b in a]
    df['log(in_rank[y]+1)'] = [np.log(b+1) for a in in_rank['y'] for b in a]
    cols = ['in_rank[x]','in_rank[y]','in_rank[x]','log(in_rank[y]+1)','log(in_rank[x]+1)','log(in_rank[y]+1)']
    df.drop_duplicates(['in_rank[x]','in_rank[y]'],keep='first').sort_values(['in_rank[x]','in_rank[y]'], axis=0)[cols].to_excel(writer, sheet_name='in neighs rank', index=False)    
    df = pd.DataFrame(columns=['out_rank[x]','out_rank[y]'])
    df['out_rank[x]'] = [b for a in out_rank['x'] for b in a]
    df['out_rank[y]'] = [b for a in out_rank['y'] for b in a]
    df['log(out_rank[x]+1)'] = [np.log(b+1) for a in out_rank['x'] for b in a]
    df['log(out_rank[y]+1)'] = [np.log(b+1) for a in out_rank['y'] for b in a]
    cols = ['out_rank[x]','out_rank[y]','out_rank[x]','log(out_rank[y]+1)','log(out_rank[x]+1)','log(out_rank[y]+1)']
    df.drop_duplicates(['out_rank[x]','out_rank[y]'], keep='first').sort_values(['out_rank[x]','out_rank[y]'], axis=0)[cols].to_excel(writer, sheet_name='out neighs rank', index=False)
    writer.save()


# standard plots
print('# plotting...')
df_plot = pd.DataFrame(columns=['x','y'])
x = [b for a in in_rank['x'] for b in a] + \
    [b for a in out_rank['x'] for b in a] + \
    [a for a in nodes_rank]
#x = [a for a in nodes_rank]
#x = [np.log(a+1) for a in nodes_rank]
y = [b for a in in_rank['y'] for b in a] + \
    [b for a in out_rank['y'] for b in a] + \
    [a for a in nodes_degree]
#y = [a for a in nodes_degree]
#y = [np.log(b+1) for a in in_rank['y'] for b in a] + \
#    [np.log(b+1) for a in out_rank['y'] for b in a] + \
#    [np.log(a+1) for a in nodes_degree]
#y = [np.log(a+1) for a in nodes_degree]
colors = ['gray'] * len([b for a in in_rank['x'] for b in a]) + \
         ['gray'] * len([b for a in out_rank['x'] for b in a]) + \
         ['blue'] * len(nodes_rank)   
#colors = ['blue'] * len(nodes_rank)   
pt_size = [2] * len([b for a in in_rank['x'] for b in a]) + \
          [2] * len([b for a in out_rank['x'] for b in a]) + \
          [8] * len(nodes_rank)
#pt_size = [8] * len(nodes_rank)
df_plot['x'] = x
df_plot['y'] = y
df_plot['colors'] = colors
df_plot['point size'] = pt_size
#print(df_plot.head())
#print(len(df_plot))
#df_plot.drop_duplicates(subset=['x','y'], keep='last', inplace=True)
#print(len(df_plot))
#xlim = [-500,24000]
xlim = [-5,250]
#xlim = [0,10.2]
ylim=[-2,200]
#ylim=[4.5,7.5]
xticks = np.arange(0, 25000, 50)
#xticks = np.arange(0, 10.1, 1)
yticks = np.arange(0, 1301, 20)
#yticks = np.arange(4.5, 7.5, 0.5)

ax = df_plot.plot.scatter(x='x', y='y', s=df_plot['point size'], color=df_plot['colors'], 
                     figsize=(19,9.5), fontsize=16, 
                     xlim=xlim, ylim=ylim, 
                     xticks=xticks, yticks=yticks,
#                     logy=True
                     )

# doesn't seem to have any effect :-(
#plt.margins(0.005)
plt.xlabel('Node Rank', fontsize=16)
plt.ylabel('Node Degree', fontsize=16)
#plt.title(plot_title+'Total Rank / Degree Curve ['+graph_name+']', fontsize=18)
plt.title(plot_title+'Neighbor Nodes ['+graph_name+']', fontsize=18)
#plt.title('In and Out Neighbor Nodes ['+graph_name+']', fontsize=18)
plt.show()



sys.exit(0)

